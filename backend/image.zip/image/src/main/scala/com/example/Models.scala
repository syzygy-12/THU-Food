package com.example

case class ImageUploadResponse(url: String)
case class ImageListResponse(images: List[String])
